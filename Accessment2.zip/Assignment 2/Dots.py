import random

first=[]
second=[]


def DotProduct(N,ListA,ListB):
    ListA=[]
    for i in range(N):
        ran= random.randint(1,1000)
        ListA[i].append(ran)
        
    ListB=[]
    for i in range(N):
        ran= random.randint(1,1000)
        ListB[i].append(ran)
        
    for n in range(0,N):
        print(ListA[n], end=" ")
        print(ListB[n], end=" ")
    print("\n")
    
DotProduct(10,first,second)
DotProduct(100,first,second)
        
 
 