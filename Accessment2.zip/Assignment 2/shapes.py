class Point:  

    def __init__(self, x, y):
        self.x = x
        self.y = y


class rectangle: 
    def __init__(self, bottomLeftCorner = Point(0,0), topRightcorner=Point(6,6)):
        self.bottomLeftCorner = bottomLeftCorner
        self.topRightcorner = topRightcorner

        self.height = topRightcorner.y - bottomLeftCorner.y  
        self.width = topRightcorner.x - bottomLeftCorner.x  
        self.area = self.height * self.width  
        self.perimeter = 2 * (self.height + self.width)  

    def intersect(bottomL_1, topR_1, bottomL_2, topR_2):  
        return not (TopR_1.x < bottomL_2.x or bottomL_1.x > topR_2.x or topR_1.y < bottomL_2.y or bottomL_1.y > topR_2.y)


rect = rectangle(Point(0, 0), Point(6, 6))  
print(rect.area)  
print(rect.perimeter)  


rectA = rectangle(Point(0, 4), Point(6, 6))
rectB = rectangle(Point(2, 5), Point(10, 6))


Rectangle.intersect(rectA.bottomLeftCorner, rectA.topRightcorner, rectB.bottomLeftCorner, rectB.topRightcorner)